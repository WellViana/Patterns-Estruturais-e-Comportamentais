package exercicio_6_1;

public class MensagemDaSexta implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é sexta!";
	}

}
