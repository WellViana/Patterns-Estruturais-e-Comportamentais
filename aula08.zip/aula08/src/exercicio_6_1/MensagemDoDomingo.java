package exercicio_6_1;

public class MensagemDoDomingo implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é domingo!";
	}

}
