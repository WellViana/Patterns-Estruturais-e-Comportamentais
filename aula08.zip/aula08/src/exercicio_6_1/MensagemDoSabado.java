package exercicio_6_1;

public class MensagemDoSabado implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é sábado!";
	}

}
