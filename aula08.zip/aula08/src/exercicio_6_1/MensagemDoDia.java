package exercicio_6_1;

public interface MensagemDoDia {
	String mensagem();
}
