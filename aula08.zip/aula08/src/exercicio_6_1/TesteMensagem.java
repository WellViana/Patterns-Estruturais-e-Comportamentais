package exercicio_6_1;

public class TesteMensagem {
	public static void main(String[] args) {
		Mensageiro mensageiro = new Mensageiro();
		mensageiro.enviarMensagem();
	}
}
