package exercicio_6_1;

public class MensagemDaTerca implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é terça!";
	}

}
