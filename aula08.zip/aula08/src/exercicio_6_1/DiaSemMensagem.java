package exercicio_6_1;

public class DiaSemMensagem implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje não tem mensagem";
	}

}
