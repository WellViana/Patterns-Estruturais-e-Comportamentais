package exercicio_6_1;

public class MensagemDaSegunda implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é segunda!";
	}

}
