package exercicio_6_1;

public class MensagemDaQuinta implements MensagemDoDia {

	@Override
	public String mensagem() {
		return "Hoje é quinta!";
	}

}
