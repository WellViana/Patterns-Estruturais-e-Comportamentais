package exercicio_6_2;

public interface Ordenacao {
	
	int[] ordenar(int v[]);

}
