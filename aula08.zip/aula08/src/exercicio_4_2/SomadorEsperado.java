package exercicio_4_2;

public interface SomadorEsperado {
	int somaVetor(int[] vetor);
	int somaInteiros(int a, int b);
}
